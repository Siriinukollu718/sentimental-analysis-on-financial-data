# sentimental-analysis-on-financial-data
Total number of records in dataset : 4846

The dataset contains two columns: "sentiment" and "News Headline"

Input: Text

Output : Sentiment that contains "Negative or Neutral or positive"

What we have done!
Data Cleaning and Vectorization

Train the classification model

Test the model on new data.
